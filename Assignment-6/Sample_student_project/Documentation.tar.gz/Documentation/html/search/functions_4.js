var searchData=
[
  ['is_5fgame_5fover',['is_game_over',['../classmain__savitch__14_1_1Othello.html#a4387d20f953aab54025760ec3f72f7ca',1,'main_savitch_14::Othello']]]
];
