var searchData=
[
  ['winning',['winning',['../classmain__savitch__14_1_1game.html#a081611c42aa66b4d91bbefeec47c7c4e',1,'main_savitch_14::game::winning()'],['../classmain__savitch__14_1_1Othello.html#a8934d1b63f73c03dae9629dbe03955d7',1,'main_savitch_14::Othello::winning()']]]
];
