var searchData=
[
  ['piece',['piece',['../classpiece.html',1,'']]],
  ['play',['play',['../classmain__savitch__14_1_1game.html#a4dbeaddb78059f7c5dcbf5cc4e026317',1,'main_savitch_14::game']]]
];
