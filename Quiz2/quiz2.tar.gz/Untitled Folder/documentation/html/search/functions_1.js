var searchData=
[
  ['display',['display',['../classCollege.html#a52ca0a164483cf5c05591cd0fb8b300c',1,'College']]]
];
