var searchData=
[
  ['display_5fmessage',['display_message',['../classmain__savitch__14_1_1game.html#ab8b87c3a1b68634861a8c0ed2b9f1992',1,'main_savitch_14::game']]]
];
