var searchData=
[
  ['clone',['clone',['../classmain__savitch__14_1_1Othello.html#ab5a505f8a6ffd860376bf074c57e8a5f',1,'main_savitch_14::Othello']]],
  ['colors_2eh',['colors.h',['../colors_8h.html',1,'']]]
];
