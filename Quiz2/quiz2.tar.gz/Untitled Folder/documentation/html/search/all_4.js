var searchData=
[
  ['readme',['README',['../md_README.html',1,'']]],
  ['remove',['remove',['../classCollege.html#a4d2ae513b36e6421fb1ca2c08459cfe6',1,'College']]]
];
